DROP DATABASE IF EXISTS hospital_management;

CREATE DATABASE hospital_management;
USE hospital_management;

--
-- Table structure for table `bill_room`
--

DROP TABLE IF EXISTS `bill_room`;
CREATE TABLE `bill_room` (
  `DischargeID` int(5) DEFAULT NULL,
  `BillingDate` date DEFAULT NULL,
  `RoomCharges` int(10) DEFAULT NULL,
  `ServiceCharges` int(10) DEFAULT NULL,
  `PaymentMode` varchar(20) DEFAULT NULL,
  `PaymentModeDetails` varchar(100) DEFAULT NULL,
  `TotalCharges` int(10) DEFAULT NULL,
  `NoOfDays` int(5) DEFAULT NULL,
  `TotalRoomCharges` int(10) DEFAULT NULL,
  `BillNo` varchar(15) NOT NULL,
  PRIMARY KEY (`BillNo`)
) ENGINE=InnoDB;

--
-- Dumping data for table `bill_room`
--

LOCK TABLES `bill_room` WRITE;
INSERT INTO `bill_room` VALUES (1,'2015-01-12',5000,500,'by Cash','Payment done successfully!',1485500,297,1485000,'120150112'),(12,'2015-01-20',2500,500,'by Credit Card','NA',500,0,0,'1220150120'),(3,'2018-04-15',5000,20000,'by Credit Card','',20000,0,0,'320180415');
UNLOCK TABLES;

--
-- Table structure for table `dischargepatient_room`
--

DROP TABLE IF EXISTS `dischargepatient_room`;
CREATE TABLE `dischargepatient_room` (
  `AdmitID` int(20) DEFAULT NULL,
  `DischargeDate` date DEFAULT NULL,
  `DP_Remarks` varchar(50) DEFAULT NULL
) ENGINE=InnoDB;

--
-- Dumping data for table `dischargepatient_room`
--

LOCK TABLES `dischargepatient_room` WRITE;
INSERT INTO `dischargepatient_room` VALUES (1,'2015-01-12','Patient recovered successfully!'),(12,'2015-01-20','Patient is stable'),(3,'2018-04-15','Patient operated');
UNLOCK TABLES;

--
-- Table structure for table `doctor`
--

DROP TABLE IF EXISTS `doctor`;
CREATE TABLE `doctor` (
  `DoctorID` int(10) NOT NULL,
  `DoctorName` varchar(20) DEFAULT NULL,
  `Surname` varchar(20) DEFAULT NULL,
  `Email` varchar(50) DEFAULT NULL,
  `ContacNo` varchar(11) DEFAULT NULL,
  `Qualifications` varchar(50) DEFAULT NULL,
  `Gender` varchar(1) DEFAULT NULL,
  `BloodGroup` varchar(5) DEFAULT NULL,
  `DateOfJoining` date DEFAULT NULL,
  `Address` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`DoctorID`)
) ENGINE=InnoDB;

--
-- Dumping data for table `doctor`
--

LOCK TABLES `doctor` WRITE;
INSERT INTO `doctor` VALUES (1,'Abdi Kahn','James kiptul','abdi123@gmail.com ','9880876532','MD,MBBS','M','A+','2014-03-20','109- Chuka'),(2,'Dennis Makau','Makau K','Makau123@gmail.com','9880756634','MD,MBBS','F','A-','2016-01-02','#111;Gayathi Temple;Whitefield;Bangalore-560066');
UNLOCK TABLES;


--
-- Table structure for table `patientregistration`
--

DROP TABLE IF EXISTS `patientregistration`;
CREATE TABLE `patientregistration` (
  `PatientID` int(10) NOT NULL,
  `PatientName` varchar(20) DEFAULT NULL,
  `Surname` varchar(20) DEFAULT NULL,
  `Email` varchar(30) DEFAULT NULL,
  `ContactNo` varchar(11) DEFAULT NULL,
  `Age` int(2) DEFAULT NULL,
  `Remarks` varchar(100) DEFAULT NULL,
  `Gen` varchar(1) DEFAULT NULL,
  `BG` varchar(3) DEFAULT NULL,
  `Address` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`PatientID`)
) ENGINE=InnoDB;

--
-- Table structure for table `registration`
--

DROP TABLE IF EXISTS `registration`;
CREATE TABLE `registration` (
  `name` varchar(20) DEFAULT NULL,
  `user_name` varchar(20) NOT NULL,
  `password` varchar(20) DEFAULT NULL,
  `email_id` varchar(30) DEFAULT NULL,
  `contact_no` int(10) DEFAULT NULL,
  PRIMARY KEY (`user_name`)
) ENGINE=InnoDB;

--
-- Table structure for table `room`
--

DROP TABLE IF EXISTS `room`;
CREATE TABLE `room` (
  `RoomNo` int(5) NOT NULL,
  `RoomType` varchar(10) DEFAULT NULL,
  `RoomCharges` int(10) DEFAULT NULL,
  `RoomStatus` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`RoomNo`)
) ENGINE=InnoDB;

--
-- Dumping data for table `room`
--

LOCK TABLES `room` WRITE;
INSERT INTO `room` VALUES (1,'General',5000,'Vacant'),(2,'General',2500,'Vacant'),(3,'Deluxe',10000,'Booked');
UNLOCK TABLES;

--
-- Table structure for table `admitpatient_room`
--

DROP TABLE IF EXISTS `admitpatient_room`;
CREATE TABLE `admitpatient_room` (
  `PatientID` int(10) NOT NULL,
  `Disease` varchar(50) DEFAULT NULL,
  `AdmitDate` date DEFAULT NULL,
  `RoomNo` int(5) NOT NULL,
  `DoctorID` int(10) NOT NULL,
  `AP_Remarks` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`PatientID`),
  KEY `RoomNo` (`RoomNo`),
  KEY `DoctorID` (`DoctorID`),
  CONSTRAINT `admitpatient_room_ibfk_1` FOREIGN KEY (`RoomNo`) REFERENCES `room` (`RoomNo`),
  CONSTRAINT `admitpatient_room_ibfk_2` FOREIGN KEY (`DoctorID`) REFERENCES `doctor` (`DoctorID`)
) ENGINE=InnoDB;



--
-- Table structure for table `services`
--

DROP TABLE IF EXISTS `services`;
CREATE TABLE `services` (
  `ServiceName` varchar(20) DEFAULT NULL,
  `ServiceDate` date DEFAULT NULL,
  `PatientID` int(10) DEFAULT NULL,
  `ServiceCharges` int(10) DEFAULT NULL,
  `ServiceID` int(10) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`ServiceID`),
  KEY `PatientID` (`PatientID`)
) ENGINE=InnoDB AUTO_INCREMENT=20;

--
-- Dumping data for table `services`
--

LOCK TABLES `services` WRITE;
INSERT INTO `services` VALUES ('General Consultation','2021-09-22',1,500,16),('General Consultation','2022-01-20',12,500,17),
('Surgery','2022-04-15',2,15000,18),('Surgery','2022-04-15',3,20000,19);
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `user_name` varchar(20) NOT NULL,
  `password` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`user_name`)
) ENGINE=InnoDB;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
INSERT INTO `users` VALUES ('Francis', '40741'), ('Eutace', '42997'), ('Jeremiah', '42990'), ('Caroline', '42929'),
('Annette', '43019'), ('Stephen', '43011'), ('David', '42490');
UNLOCK TABLES;


